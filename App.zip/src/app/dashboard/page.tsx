"use client";

import React, { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../../../convex/_generated/api";

export default function DashboardPage() {
  const [isProcessing, setIsProcessing] = useState(false);

  // 1. CHARGEMENT DES DONNÉES EN TEMPS RÉEL
  const myProfile = useQuery(api.users.getMe);
  const myArticles = useQuery(api.articles.getFeedArticles); // Pour simplifier, on filtre mes articles dans le composant

  // MUTATIONS CONVEX
  const buyDeliverySubscription = useMutation(api.users.subscribeToDelivery);
  const triggerArticleBoost = useMutation(api.articles.boostArticle);
  const requestCashout = useMutation(api.users.requestWithdrawal);

  if (!myProfile) {
    return <div className="text-center py-20 text-sm text-white/40 animate-pulse">Chargement de votre comptabilité...</div>;
  }

  // Filtrer uniquement les articles qui m'appartiennent
  const myOwnArticles = myArticles?.filter(art => art.sellerId === myProfile._id) || [];

  // 2. ACTIONS FINANCIÈRES & MONÉTISATION
  const handleSubscribeDelivery = async () => {
    setIsProcessing(true);
    try {
      await buyDeliverySubscription();
      alert("Félicitations ! Votre abonnement livraison partenaire est actif pour 30 jours.");
    } catch (err) {
      alert("Erreur abonnement : " + err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleBoost = async (articleId: any) => {
    try {
      // On booste pour 24 heures par défaut
      await triggerArticleBoost({ articleId, durationInHours: 24 });
      alert("Votre article est maintenant propulsé tout en haut du fil d'actualité ! 🔥");
    } catch (err) {
      alert("Erreur boost : " + err);
    }
  };

  const handleWithdraw = async () => {
    if (myProfile.withdrawableBalance <= 0) {
      alert("Vous n'avez pas de fonds disponibles pour un retrait.");
      return;
    }
    
    const phone = prompt("Entrez votre numéro Mobile Money (Mvola/Orange/Airtel) pour le transfert :", myProfile.phone || "");
    if (!phone) return;

    try {
      await requestCashout({ amount: myProfile.withdrawableBalance, phoneNumber: phone });
      alert("Demande de retrait enregistrée ! Le transfert Mobile Money sera effectué sur votre numéro sous 2 heures.");
    } catch (err) {
      alert("Erreur retrait : " + err);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      
      {/* HEADER DE LA PAGE */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-black tracking-wide">Mon Espace Pro</h1>
          <p className="text-xs text-white/40">Gérez vos gains et la visibilité de vos articles</p>
        </div>
        {myProfile.isVerified && (
          <span className="px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[10px] font-bold tracking-wider uppercase">
            🟢 Vendeur Vérifié
          </span>
        )}
      </div>

      {/* ====================================================
          LES PORTE-MONNAIES (LIQUID GLASS PANELS)
          ==================================================== */}
      <div className="grid grid-cols-2 gap-4">
        {/* Balance en attente (Escrow bloqué) */}
        <div className="p-4 rounded-3xl bg-white/[0.03] backdrop-blur-xl border border-white/[0.06] shadow-glass">
          <span className="text-[10px] uppercase font-bold tracking-wider text-white/40">Gains en attente</span>
          <p className="text-xl font-black text-amber-300 mt-1">
            {myProfile.pendingBalance.toLocaleString("fr-FR")} Ar
          </p>
          <p className="text-[9px] text-white/30 mt-1 leading-tight">Sécurisé chez App'Varotra. Libéré dès réception du colis.</p>
        </div>

        {/* Balance retirable immédiatement */}
        <div className="p-4 rounded-3xl bg-white/[0.06] backdrop-blur-xl border border-white/[0.12] shadow-glass flex flex-col justify-between group">
          <div>
            <span className="text-[10px] uppercase font-bold tracking-wider text-white/50">Solde disponible</span>
            <p className="text-xl font-black bg-gradient-to-r from-white to-white/80 bg-clip-text text-transparent mt-1">
              {myProfile.withdrawableBalance.toLocaleString("fr-FR")} Ar
            </p>
          </div>
          <button
            onClick={handleWithdraw}
            className="w-full mt-3 py-1.5 text-xs font-bold text-center bg-white text-black rounded-xl hover:bg-white/90 transition-all active:scale-95 shadow-md"
          >
            Retirer mon cash
          </button>
        </div>
      </div>

      {/* ====================================================
          ZONE ABONNEMENT LIVRAISON PARTENAIRE
          ==================================================== */}
      <div className="p-5 rounded-3xl bg-gradient-to-br from-purple-950/20 to-pink-950/10 backdrop-blur-xl border border-purple-500/20 shadow-glass flex items-center justify-between gap-4">
        <div className="space-y-1">
          <h3 className="text-sm font-bold text-purple-200">Abonnement Livraisons</h3>
          <p className="text-xs text-white/60 leading-snug">
            {myProfile.isSubscribedToDelivery 
              ? `Actif ! Vos acheteurs ne payent aucun frais de livraison.`
              : "Prenez le forfait mensuel pour inclure la livraison gratuite sur tous vos articles."}
          </p>
        </div>
        
        {!myProfile.isSubscribedToDelivery ? (
          <button
            disabled={isProcessing}
            onClick={handleSubscribeDelivery}
            className="px-4 py-2.5 text-xs font-bold whitespace-nowrap bg-gradient-to-r from-purple-500/40 to-pink-500/40 border border-white/20 rounded-2xl hover:from-purple-500/60 hover:to-pink-500/60 transition-all"
          >
            S'abonner
          </button>
        ) : (
          <span className="text-xs text-emerald-400 font-bold bg-emerald-500/10 px-3 py-1.5 rounded-xl border border-emerald-500/20 flex-shrink-0">✓ Actif</span>
        )}
      </div>

      {/* ====================================================
          GESTION DES ARTICLES & SYSTÈME DE BOOST
          ==================================================== */}
      <div className="space-y-3">
        <h2 className="text-xs font-bold uppercase tracking-widest text-white/40 px-1">Mes articles en vente ({myOwnArticles.length})</h2>
        
        {myOwnArticles.length === 0 ? (
          <div className="p-6 text-center text-xs text-white/30 rounded-2xl bg-white/[0.01] border border-white/[0.05]">
            Vous n'avez aucun article en vente pour le moment.
          </div>
        ) : (
          <div className="space-y-2.5">
            {myOwnArticles.map((art) => (
              <div 
                key={art._id}
                className="p-3 rounded-2xl bg-white/[0.03] border border-white/[0.06] flex items-center justify-between gap-3 shadow-sm"
              >
                <div className="flex items-center gap-3 truncate">
                  <img src={art.images[0]} alt="" className="w-10 h-10 rounded-xl object-cover bg-black/20 flex-shrink-0" />
                  <div className="truncate">
                    <h4 className="text-xs font-semibold truncate text-white/90">{art.title}</h4>
                    <p className="text-sm font-black text-white/60">{art.price.toLocaleString("fr-FR")} Ar</p>
                  </div>
                </div>

                {/* Bouton Boost contextuel */}
                {art.status === "AVAILABLE" && (
                  <button
                    onClick={() => handleBoost(art._id)}
                    disabled={art.isBoosted}
                    className={`px-3 py-1.5 text-[11px] font-bold rounded-xl transition-all flex-shrink-0
                      ${art.isBoosted 
                        ? "bg-yellow-500/10 text-yellow-400 border border-yellow-500/30" 
                        : "bg-white/[0.05] border border-white/10 hover:bg-white/[0.1] text-white"
                      }`}
                  >
                    {art.isBoosted ? "🔥 Mis en avant" : "🚀 Booster (24h)"}
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
}
