"use client";

import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { StoriesBar } from "@/components/ui/StoriesBar";
import { ArticleCard } from "@/components/ui/ArticleCard";

export default function HomePage() {
  // 1. Chargement des données en temps réel depuis Convex
  const articles = useQuery(api.articles.getFeedArticles);
  const stories = useQuery(api.stories.getActiveStories);
  const initiatePurchase = useMutation(api.escrow.initiateTransaction);

  // 2. Gestion du clic sur "Acheter" (Déclenche le système de Tiers de Confiance)
  const handleBuyProduct = async (articleId: any) => {
    try {
      // Par défaut, on lance en MVOLA pour le MVP, l'utilisateur affinera dans le chat
      const result = await initiatePurchase({
        articleId,
        paymentMethod: "MVOLA",
      });
      
      // Redirection automatique vers le chat sécurisé créé par l'Escrow
      window.location.href = `/chat/${result.conversationId}`;
    } catch (error) {
      alert("Erreur lors de l'initiation de l'achat : " + error);
    }
  };

  const handleOpenStory = (sellerId: string) => {
    console.log("Ouvrir la story du vendeur :", sellerId);
    // Ici, tu ouvriras une fenêtre modale plein écran pour faire défiler la story
  };

  return (
    <div className="space-y-6">
      
      {/* HEADER DE L'APPLICATION (Effet Verre Bombé) */}
      <header className="w-full px-5 py-4 rounded-2xl bg-white/[0.03] backdrop-blur-xl border border-white/[0.08] shadow-glass flex items-center justify-between">
        <h1 className="text-xl font-black tracking-wider bg-gradient-to-r from-white via-purple-200 to-pink-300 bg-clip-text text-transparent">
          App'Varotra
        </h1>
        
        {/* Boutons d'action rapides (Recherche, Profil) */}
        <div className="flex items-center gap-3">
          <button className="p-2 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] text-sm transition-colors">
            🔍
          </button>
          <button className="p-2 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] text-sm transition-colors">
            🛒
          </button>
        </div>
      </header>

      {/* SECTION STORIES (Instagram Style) */}
      <section className="space-y-2">
        <h2 className="text-xs font-bold uppercase tracking-widest text-white/40 px-1">
          Nouveautés du jour
        </h2>
        {/* On passe les données réelles de Convex ou un tableau vide pendant le chargement */}
        <StoriesBar 
          stories={stories || []} 
          onStoryClick={handleOpenStory} 
        />
      </section>

      {/* SECTION ARTICLES FEED (Vinted Style) */}
      <section className="space-y-3">
        <h2 className="text-xs font-bold uppercase tracking-widest text-white/40 px-1">
          Fil d'actualité
        </h2>

        {/* État de chargement initial */}
        {articles === undefined && (
          <div className="grid grid-cols-2 gap-4">
            {[1, 2, 3, 4].map((n) => (
              <div key={n} className="aspect-[4/6] rounded-3xl bg-white/[0.02] animate-pulse border border-white/[0.05]" />
            ))}
          </div>
        )}

        {/* Si aucun article n'est disponible sur le marché malgache */}
        {articles !== undefined && articles.length === 0 && (
          <div className="p-8 text-center rounded-2xl bg-white/[0.02] backdrop-blur-md border border-white/[0.05]">
            <p className="text-sm text-white/50">Aucun article disponible pour le moment.</p>
          </div>
        )}

        {/* Grille d'articles en double colonne (idéal sur Mobile) */}
        {articles && (
          <div className="grid grid-cols-2 gap-4">
            {articles.map((article) => (
              <ArticleCard
                key={article._id}
                title={article.title}
                price={article.price}
                currency={article.currency}
                imageUrl={article.images[0]}
                sellerName={article.sellerName}
                sellerAvatar={article.sellerAvatar}
                isSellerVerified={article.isSellerVerified}
                isBoosted={article.isBoosted}
                hasDeliverySubscription={article.hasDeliverySubscription}
                onBuyClick={() => handleBuyProduct(article._id)}
              />
            ))}
          </div>
        )}
      </section>

    </div>
  );
}
