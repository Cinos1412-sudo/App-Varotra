"use client";

import React, { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "../../../../convex/_generated/api";

export default function PublishPage() {
  // 1. ÉTATS DU FORMULAIRE
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [currency, setCurrency] = useState<"MGA" | "USDT">("MGA");
  const [publishType, setPublishType] = useState<"FEED" | "STORY">("FEED");
  
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // 2. MUTATIONS CONVEX
  const createArticle = useMutation(api.articles.createArticle);
  const createStory = useMutation(api.stories.addStory); // Doit correspondre au nom exact de ton fichier stories.ts

  // Simulation d'un upload photo (Prise de vue caméra sur mobile)
  const handlePickPhotoSimulation = () => {
    // Unsplash aléatoire typé mode/tech pour le test visuel
    const mockImages = [
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=600&q=80", // Sneakers
      "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80", // Casque
      "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=600&q=80"  // Sac
    ];
    const randomImage = mockImages[Math.floor(Math.random() * mockImages.length)];
    setPreviewImage(randomImage);
  };

  // 3. SOUMISSION DU FORMULAIRE
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!previewImage) {
      alert("Veuillez ajouter une photo de votre article !");
      return;
    }
    if (!title && publishType === "FEED") return;
    if (!price) return;

    setIsSubmitting(true);

    try {
      const numericPrice = parseFloat(price);

      if (publishType === "STORY") {
        // Option A : Publication flash de 24 heures
        await createStory({
          mediaUrl: previewImage,
          mediaType: "IMAGE",
        });
        alert("Votre Story est en ligne pour 24 heures ! 📸");
      } else {
        // Option B : Publication standard sur le marché
        await createArticle({
          title,
          description,
          price: numericPrice,
          currency,
          images: [previewImage],
        });
        alert("Votre annonce a été publiée sur le fil d'actualité ! 🛍️");
      }

      // Réinitialisation du formulaire après succès
      setTitle("");
      setDescription("");
      setPrice("");
      setPreviewImage(null);
      window.location.href = "/"; // Retour à l'accueil
    } catch (err) {
      alert("Erreur lors de la publication : " + err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-black tracking-wide">Mettre en vente</h1>
        <p className="text-xs text-white/40">Prenez une photo claire pour attirer les acheteurs malgaches</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        
        {/* INTERRUPTEUR DE FORMAT (FEED VS STORY) */}
        <div className="p-1 rounded-2xl bg-white/[0.03] border border-white/[0.06] flex gap-1">
          <button
            type="button"
            onClick={() => setPublishType("FEED")}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
              publishType === "FEED" ? "bg-white text-black shadow-md" : "text-white/60 hover:text-white"
            }`}
          >
            🛍️ Annonce Classique
          </button>
          <button
            type="button"
            onClick={() => setPublishType("STORY")}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
              publishType === "STORY" ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-md" : "text-white/60 hover:text-white"
            }`}
          >
            ⚡ Story Flash (24h)
          </button>
        </div>

        {/* ZONE CAPTURE PHOTO (Look Verre Givré Bombé) */}
        <div 
          onClick={handlePickPhotoSimulation}
          className="relative aspect-[4/3] w-full rounded-3xl border border-dashed border-white/20 bg-white/[0.02] hover:bg-white/[0.05] cursor-pointer flex flex-col items-center justify-center p-4 transition-all overflow-hidden shadow-glass group"
        >
          {previewImage ? (
            <>
              <img src={previewImage} alt="Preview" className="absolute inset-0 w-full h-full object-cover group-hover:scale-102 transition-transform duration-300" />
              <div className="absolute bottom-3 right-3 px-3 py-1.5 text-[10px] font-bold bg-black/60 backdrop-blur-md rounded-xl text-white/80">
                Changer de photo 🔄
              </div>
            </>
          ) : (
            <div className="text-center space-y-2">
              <span className="text-3xl">📸</span>
              <p className="text-xs font-bold text-white/80">Ajouter une photo</p>
              <p className="text-[10px] text-white/40">Cliquez pour simuler l'appareil photo</p>
            </div>
          )}
        </div>

        {/* LES CHAMPS DU FORMULAIRE */}
        <div className="space-y-3 p-4 rounded-3xl bg-white/[0.02] backdrop-blur-xl border border-white/[0.06] shadow-glass">
          
          {/* Le titre et la description ne servent que pour une annonce classique (pas pour les stories) */}
          {publishType === "FEED" && (
            <>
              <div className="space-y-1">
                <label className="text-[10px] font-bold uppercase tracking-wider text-white/40">Titre de l'objet</label>
                <input
                  type="text"
                  required={publishType === "FEED"}
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Ex: Hoodie vintage Taille M, iPhone 13 Pro..."
                  className="w-full p-3 bg-white/[0.04] border border-white/[0.08] rounded-xl text-xs text-white placeholder-white/20 focus:outline-none focus:border-purple-500/40 focus:bg-white/[0.06] transition-all"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold uppercase tracking-wider text-white/40">Description</label>
                <textarea
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="État du produit, lieu de récupération (Tana, Tamatave...)"
                  className="w-full p-3 bg-white/[0.04] border border-white/[0.08] rounded-xl text-xs text-white placeholder-white/20 focus:outline-none focus:border-purple-500/40 focus:bg-white/[0.06] transition-all resize-none"
                />
              </div>
            </>
          )}

          {/* Saisie financière (Prix + Devise) */}
          <div className="grid grid-cols-3 gap-3">
            <div className="col-span-2 space-y-1">
              <label className="text-[10px] font-bold uppercase tracking-wider text-white/40">Prix</label>
              <input
                type="number"
                required
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="Ex: 45000"
                className="w-full p-3 bg-white/[0.04] border border-white/[0.08] rounded-xl text-xs text-white placeholder-white/20 focus:outline-none focus:border-purple-500/40 focus:bg-white/[0.06] transition-all"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold uppercase tracking-wider text-white/40">Devise</label>
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value as any)}
                className="w-full p-3 bg-white/[0.04] border border-white/[0.08] rounded-xl text-xs text-white/80 focus:outline-none focus:border-purple-500/40 focus:bg-white/[0.06] transition-all"
              >
                <option value="MGA" className="bg-[#0b0813] text-white">MGA (Ar)</option>
                <option value="USDT" className="bg-[#0b0813] text-white">USDT</option>
              </select>
            </div>
          </div>

        </div>

        {/* BOUTON DE VALIDATION GLOWING EFFECT */}
        <button
          type="submit"
          disabled={isSubmitting}
          className={`w-full py-3.5 text-xs font-black uppercase tracking-widest text-white rounded-2xl border transition-all duration-300 shadow-md
            ${publishType === "STORY"
              ? "bg-gradient-to-r from-purple-500 to-pink-500 border-purple-400/30 hover:opacity-90 active:scale-98"
              : "bg-white/10 hover:bg-white/15 border-white/20 active:scale-98"
            } disabled:opacity-50`}
        >
          {isSubmitting ? "Publication en cours..." : "Lancer la vente 🚀"}
        </button>

      </form>
    </div>
  );
}
