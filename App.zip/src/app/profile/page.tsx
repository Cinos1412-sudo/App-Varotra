"use client";

import React, { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../../../convex/_generated/api";
import { useClerk } from "@clerk/nextjs";

export default function ProfilePage() {
  const { signOut } = useClerk();
  const [isSubmittingCin, setIsSubmittingCin] = useState(false);

  // 1. RÉCUPÉRER LE PROFIL DEPUIS CONVEX
  const myProfile = useQuery(api.users.getMe);
  const submitCinMutation = useMutation(api.users.requestVerification);

  if (!myProfile) {
    return <div className="text-center py-20 text-sm text-white/40 animate-pulse">Chargement de votre profil...</div>;
  }

  // 2. SIMULATION DE SOUMISSION DE LA CIN (Carte d'Identité Nationale)
  const handleVerifyAccount = async () => {
    setIsSubmittingCin(true);
    try {
      // Simulation d'une URL de photo de carte d'identité stockée
      const mockCinUrl = "https://images.unsplash.com/photo-1554774853-aae0a22c8aa4?auto=format&fit=crop&w=600&q=80";
      
      await submitCinMutation({ idCardUrl: mockCinUrl });
      alert("Votre pièce d'identité a été envoyée ! Nos équipes vont vérifier votre compte sous 24h. 🟢");
    } catch (err) {
      alert("Erreur lors de l'envoi de la CIN : " + err);
    } finally {
      setIsSubmittingCin(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      
      {/* CARD UTILISATEUR PRINCIPALE (Look Verre Bombé Premium) */}
      <div className="p-6 rounded-3xl bg-white/[0.03] backdrop-blur-xl border border-white/[0.08] shadow-glass flex flex-col items-center text-center space-y-3 relative overflow-hidden">
        
        {/* Avatar avec cercle lumineux liquide */}
        <div className="relative w-24 h-24 p-[3px] rounded-full bg-gradient-to-tr from-purple-500 to-pink-500 shadow-lg">
          <div className="w-full h-full rounded-full overflow-hidden bg-black/40">
            <img 
              src={myProfile.avatarUrl || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80"} 
              alt={myProfile.username} 
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        <div>
          <h2 className="text-lg font-black flex items-center justify-center gap-1.5">
            {myProfile.username}
            {myProfile.isVerified && (
              <span className="text-emerald-400 text-xs" title="Compte Vérifié">🟢</span>
            )}
          </h2>
          <p className="text-xs text-white/40">{myProfile.email}</p>
          <p className="text-xs text-purple-300 font-medium mt-1">{myProfile.phone || "Aucun numéro associé"}</p>
        </div>
      </div>

      {/* BLOC SYSTÈME DE VÉRIFICATION (BADGE VERT) */}
      <div className="p-5 rounded-3xl bg-white/[0.02] backdrop-blur-md border border-white/[0.05] shadow-sm space-y-3">
        <div className="flex items-start gap-3">
          <span className="text-xl">🛡️</span>
          <div className="space-y-0.5">
            <h3 className="text-xs font-bold uppercase tracking-wider text-white/80">Badge de Confiance Émeraude</h3>
            <p className="text-xs text-white/50 leading-relaxed">
              Devenez un membre certifié. Les comptes vérifiés par CIN rassurent les acheteurs et vendent 3x plus vite.
            </p>
          </div>
        </div>

        {/* Bouton ou statut dynamique selon Convex */}
        {myProfile.verificationStatus === "NOT_STARTED" && (
          <button
            onClick={handleVerifyAccount}
            disabled={isSubmittingCin}
            className="w-full py-2.5 text-xs font-bold bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl transition-all active:scale-98"
          >
            {isSubmittingCin ? "Envoi en cours..." : "Soumettre ma pièce d'identité (CIN)"}
          </button>
        )}

        {myProfile.verificationStatus === "PENDING" && (
          <div className="w-full py-2.5 text-xs text-center font-bold bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-xl">
            ⏳ Vérification en cours par nos modérateurs
          </div>
        )}

        {myProfile.verificationStatus === "VERIFIED" && (
          <div className="w-full py-2.5 text-xs text-center font-bold bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-xl">
            ✓ Votre compte est certifié conforme
          </div>
        )}
      </div>

      {/* BOUTONS DE PARAMÈTRES ET SÉCURITÉ */}
      <div className="space-y-2">
        <button className="w-full p-4 rounded-2xl bg-white/[0.01] hover:bg-white/[0.04] border border-white/[0.04] text-left text-xs font-semibold flex items-center justify-between transition-colors">
          <span>📦 Mes achats en cours (Suivi Colis)</span>
          <span className="text-white/30">➔</span>
        </button>

        <button className="w-full p-4 rounded-2xl bg-white/[0.01] hover:bg-white/[0.04] border border-white/[0.04] text-left text-xs font-semibold flex items-center justify-between transition-colors">
          <span>📜 Historique de mes transactions</span>
          <span className="text-white/30">➔</span>
        </button>

        {/* Bouton de Déconnexion Clerk relié à l'infrastructure */}
        <button 
          onClick={() => signOut(() => window.location.href = "/")}
          className="w-full p-4 rounded-2xl bg-red-500/10 hover:bg-red-500/15 border border-red-500/20 text-left text-xs font-bold text-red-400 flex items-center justify-between transition-colors"
        >
          <span>🚪 Se déconnecter de l'application</span>
          <span>➔</span>
        </button>
      </div>

    </div>
  );
}
