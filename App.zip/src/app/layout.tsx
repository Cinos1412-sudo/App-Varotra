import "@/app/globals.css";
import { Providers } from "./providers";

// Configuration des métadonnées de l'application
export const metadata = {
  title: "App'Varotra - Social Shopping Madagascar",
  description: "Achetez et vendez vos articles à Mada en toute sécurité via notre Tiers de Confiance.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fr" className="h-full bg-[#0b0813] text-white overflow-x-hidden">
      <body className="relative min-h-full font-sans antialiased selection:bg-purple-500/30">
        
        {/* ====================================================
            ARRÈRE-PLAN LIQUIDE EN MOUVEMENT (Sous les panneaux de verre)
            ==================================================== */}
        <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
          {/* Blob Supérieur - Violet / Rose Néon */}
          <div 
            className="absolute top-[-10%] left-[-10%] w-[350px] h-[350px] md:w-[600px] md:h-[600px] bg-gradient-to-tr from-purple-600 to-pink-500 opacity-30 mix-blend-screen filter blur-[80px] animate-fluid-blob" 
          />
          
          {/* Blob Inférieur - Turquoise Lagon (Ambiance Madagascar) */}
          <div 
            className="absolute bottom-[10%] right-[-5%] w-[300px] h-[300px] md:w-[500px] md:h-[500px] bg-gradient-to-br from-cyan-500 to-blue-600 opacity-25 mix-blend-screen filter blur-[90px] animate-fluid-blob" 
            style={{ animationDelay: "-4s" }} 
          />
        </div>

        {/* ====================================================
            INJECTION DE L'AUTHENTIFICATION ET DE LA BASE DE DONNÉES
            ==================================================== */}
        <Providers>
          
          {/* CONTENEUR PRINCIPAL DE L'APPLI (Format Mobile-First Centré) */}
          <main className="max-w-md mx-auto min-h-screen px-4 pb-24 pt-6 relative z-10">
            {children}
          <BottomNav/></main>
          
        </Providers>
        
      </body>
    </html>
  );
}
