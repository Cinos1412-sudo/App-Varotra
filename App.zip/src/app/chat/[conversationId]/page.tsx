"use client";

import React, { useState, useRef, useEffect } from "react";
import { useQuery, useMutation, useAction } from "convex/react";
import { api } from "../../../../convex/_generated/api";
import { useParams } from "next/navigation";

export default function ChatPage() {
  const params = useParams();
  const conversationId = params.conversationId as any;

  // 1. ÉTATS LOCAUX
  const [inputText, setInputText] = useState("");
  const [isUploading, setIsUploading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // 2. DATA CONVEX (Temps réel)
  const myProfile = useQuery(api.users.getMe);
  const messages = useQuery(api.conversations.getMessages, { conversationId });
  const escrow = useQuery(api.escrow.getEscrowStatus, { articleId: conversationId }); // ID conv = ID article dans notre logique simplifiée

  // MUTATIONS & ACTIONS
  const sendTextMessage = useMutation(api.conversations.sendMessage);
  const submitScreenshot = useMutation(api.escrow.submitPaymentScreenshot);
  const releaseEscrowFunds = useMutation(api.escrow.releaseFunds);
  const triggerOcrAnalysis = useAction(api.ocr.parseScreenshotAction);

  // Auto-scroll vers le bas lors d'un nouveau message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  if (!myProfile || !messages) {
    return <div className="text-center py-20 text-sm text-white/40 animate-pulse">Chargement de votre espace sécurisé...</div>;
  }

  // 3. ACTIONS UTILISATEUR
  const handleSendText = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    
    await sendTextMessage({ conversationId, text: inputText });
    setInputText("");
  };

  // Simulation d'un upload de screenshot (Mvola / Orange Money)
  const handleUploadScreenshotSimulation = async () => {
    setIsUploading(true);
    try {
      // En situation réelle, tu uploades le fichier sur Convex Storage ou UploadThing et tu récupères l'URL
      const mockStorageUrl = "https://images.unsplash.com/photo-1616077168079-7e09a677fb2c?auto=format&fit=crop&w=600&q=80";

      // 1. Enregistrer la capture dans l'Escrow et le Chat
      const { messageId } = await submitScreenshot({
        escrowId: escrow!._id,
        conversationId,
        screenshotUrl: mockStorageUrl,
      });

      // 2. Déclencher immédiatement l'Action OCR en tâche de fond (Analyse IA)
      if (escrow) {
        triggerOcrAnalysis({
          messageId,
          escrowId: escrow._id,
          screenshotUrl: mockStorageUrl,
        });
      }
    } catch (err) {
      alert("Erreur transfert : " + err);
    } finally {
      setIsUploading(false);
    }
  };

  const handleReleaseFunds = async () => {
    if (!escrow) return;
    if (confirm("Confirmez-vous avoir reçu votre colis ? L'argent sera versé au vendeur.")) {
      await releaseEscrowFunds({ escrowId: escrow._id });
    }
  };

  return (
    <div className="flex flex-col h-[88vh] bg-white/[0.02] backdrop-blur-2xl rounded-3xl border border-white/[0.08] shadow-glass overflow-hidden">
      
      {/* ====================================================
          BANDEAU SUPÉRIEUR : STATUT DE L'ESCROW (TIERS DE CONFIANCE)
          ==================================================== */}
      <div className="p-4 border-b border-white/[0.08] bg-white/[0.02] flex items-center justify-between">
        <div>
          <span className="text-[10px] uppercase font-bold tracking-widest text-white/40">Garantie App'Varotra</span>
          <div className="flex items-center gap-2 mt-0.5">
            <span className={`w-2 h-2 rounded-full animate-pulse 
              ${escrow?.status === "FUNDS_HELD" ? "bg-emerald-400" : "bg-amber-400"}`} 
            />
            <h2 className="text-sm font-bold">
              {escrow?.status === "INITIATED" && "En attente du paiement..."}
              {escrow?.status === "SCREENSHOT_SUBMITTED" && "Analyse du reçu par l'IA..."}
              {escrow?.status === "FUNDS_HELD" && "Argent sécurisé au séquestre"}
              {escrow?.status === "RELEASED" && "Transaction finalisée ✓"}
            </h2>
          </div>
        </div>

        {/* Bouton d'action contextuel pour l'acheteur */}
        {escrow?.status === "FUNDS_HELD" && myProfile._id === escrow.buyerId && (
          <button
            onClick={handleReleaseFunds}
            className="px-3 py-1.5 text-xs font-bold bg-gradient-to-r from-emerald-500/80 to-teal-500/80 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl shadow-md border border-emerald-400/20 transition-all active:scale-95"
          >
            Libérer les fonds
          </button>
        )}
      </div>

      {/* ====================================================
          ZONE DES MESSAGES (FILTRAGE PAR TYPE)
          ==================================================== */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
        {messages.map((msg) => {
          const isMe = msg.senderId === myProfile._id;

          // 1. Rendu des Notifications Système (Robots, validations, alertes)
          if (msg.type === "SYSTEM_NOTIFICATION") {
            return (
              <div key={msg._id} className="mx-auto max-w-[90%] p-3 rounded-2xl bg-purple-950/30 border border-purple-500/20 backdrop-blur-md text-center text-xs text-purple-200">
                {msg.text}
              </div>
            );
          }

          // 2. Rendu des Captures d'Écran de paiement Mobile Money
          if (msg.type === "PAYMENT_SCREENSHOT") {
            return (
              <div key={msg._id} className={`flex flex-col max-w-[70%] space-y-1 ${isMe ? "ml-auto items-end" : "mr-auto items-start"}`}>
                <span className="text-[10px] text-white/40">Reçu de paiement soumis</span>
                <div className="relative rounded-2xl overflow-hidden border border-white/10 bg-black/40 aspect-[3/4] w-44 shadow-lg">
                  <img src={msg.screenshotUrl} alt="Reçu" className="w-full h-full object-cover opacity-80" />
                  {!msg.ocrProcessed && (
                    <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex flex-col items-center justify-center p-2 text-center">
                      <div className="w-5 h-5 border-2 border-purple-400 border-t-transparent rounded-full animate-spin mb-2" />
                      <span className="text-[10px] text-purple-200 font-medium">L'IA extrait le code de transaction...</span>
                    </div>
                  )}
                </div>
              </div>
            );
          }

          // 3. Rendu des Messages Standard (Bulle verte/Bulle transparente)
          return (
            <div key={msg._id} className={`flex max-w-[75%] flex-col ${isMe ? "ml-auto items-end" : "mr-auto items-start"}`}>
              <div className={`p-3 rounded-2xl text-sm ${
                isMe 
                  ? "bg-gradient-to-br from-purple-600/50 to-pink-600/50 text-white rounded-br-none border border-white/10" 
                  : "bg-white/[0.06] text-white/90 rounded-bl-none border border-white/[0.05]"
              }`}>
                {msg.text}
              </div>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* ====================================================
          BARRE D'INPUT ET DE SÉLECTION DE SCREENSHOT
          ==================================================== */}
      <div className="p-3 border-t border-white/[0.08] bg-black/20 backdrop-blur-xl">
        <form onSubmit={handleSendText} className="flex items-center gap-2">
          
          {/* Bouton Raccourci : Envoyer un reçu (Mobile Money) */}
          {escrow?.status === "INITIATED" && myProfile._id === escrow.buyerId && (
            <button
              type="button"
              disabled={isUploading}
              onClick={handleUploadScreenshotSimulation}
              className="p-3 rounded-xl bg-white/[0.05] border border-white/10 hover:bg-white/[0.1] text-xs font-bold transition-all disabled:opacity-50 flex-shrink-0"
              title="Envoyer la capture du Mobile Money"
            >
              {isUploading ? "..." : "📸 Recu"}
            </button>
          )}

          {/* Champ texte translucide */}
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Écrivez votre message..."
            className="flex-1 px-4 py-3 bg-white/[0.04] border border-white/[0.1] rounded-xl text-sm text-white placeholder-white/30 focus:outline-none focus:border-purple-500/50 focus:bg-white/[0.07] transition-all"
          />

          {/* Bouton Envoyer */}
          <button
            type="submit"
            className="p-3 rounded-xl bg-purple-500/30 hover:bg-purple-500/50 border border-purple-400/30 text-sm transition-all flex-shrink-0"
          >
            ➔
          </button>
        </form>
      </div>

    </div>
  );
}
