import { clerkMiddleware, createRouteMatcher } from "@clerk/nextjs/server";

// On définit les routes qui nécessitent d'être connecté
const isProtectedRoute = createRouteMatcher([
  "/dashboard(.*)",
  "/publish(.*)",
  "/chat(.*)",
]);

export default clerkMiddleware((auth, req) => {
  if (isProtectedRoute(req)) auth().protect();
});

export const config = {
  matcher: [
    // Protéger toutes les routes internes, ignorer les fichiers statiques et Next.js
    "/((?!_next|[^?]*\\.[^?]*$$).*)",
    "/(api|trpc)(.*)",
  ],
};
