import React from "react";

interface StoryGroup {
  sellerId: string;
  sellerName: string;
  sellerAvatar: string;
  isSellerVerified: boolean;
}

interface StoriesBarProps {
  stories: StoryGroup[];
  onStoryClick: (sellerId: string) => void;
}

export const StoriesBar: React.FC<StoriesBarProps> = ({ stories, onStoryClick }) => {
  // Si aucune story n'est active, on affiche un petit message incitatif
  if (stories.length === 0) {
    return (
      <div className="w-full p-4 rounded-2xl bg-white/[0.02] backdrop-blur-md border border-white/[0.05] text-center text-xs text-white/40">
        ✨ Aucune story pour le moment. Soyez le premier vendeur à en publier une !
      </div>
    );
  }

  // Astuce : On filtre les doublons pour n'avoir qu'une seule bulle par vendeur
  const uniqueSellers = stories.reduce<StoryGroup[]>((acc, current) => {
    const x = acc.find(item => item.sellerId === current.sellerId);
    if (!x) acc.push(current);
    return acc;
  }, []);

  return (
    <div className="w-full overflow-x-auto no-scrollbar py-2">
      <div className="flex items-center gap-4 px-2">
        
        {/* Bulle "Ajouter une Story" pour l'utilisateur actuel */}
        <div className="flex flex-col items-center gap-1.5 cursor-pointer flex-shrink-0 group">
          <div className="relative w-16 h-16 rounded-full bg-white/[0.05] border border-white/[0.15] flex items-center justify-center transition-transform duration-300 group-hover:scale-105 shadow-glass">
            <span className="text-xl font-light text-white/80 group-hover:text-white">+</span>
          </div>
          <span className="text-[11px] text-white/50 font-medium">Ma story</span>
        </div>

        {/* Liste des stories des vendeurs de Madagascar */}
        {uniqueSellers.map((story) => (
          <div 
            key={story.sellerId}
            onClick={() => onStoryClick(story.sellerId)}
            className="flex flex-col items-center gap-1.5 cursor-pointer flex-shrink-0 group"
          >
            {/* Anneau "Liquid Glass" dégradé néon autour de l'avatar */}
            <div className="relative w-16 h-16 p-[2px] rounded-full bg-gradient-to-tr from-purple-500 via-pink-500 to-cyan-400 transition-transform duration-300 group-hover:scale-105 shadow-lg">
              <div className="w-full h-full rounded-full border border-[#0b0813] overflow-hidden bg-black/40">
                <img 
                  src={story.sellerAvatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=80&q=80"} 
                  alt={story.sellerName}
                  className="w-full h-full object-cover"
                />
              </div>
              
              {/* Badge vérifié miniature sur la story */}
              {story.isSellerVerified && (
                <span className="absolute bottom-0 right-0 w-4 h-4 bg-emerald-500 rounded-full border-2 border-[#0b0813] flex items-center justify-center text-[8px]">
                  ✓
                </span>
              )}
            </div>
            
            {/* Nom du vendeur sous sa story */}
            <span className="text-[11px] text-white/80 font-medium max-w-[68px] truncate">
              {story.sellerName}
            </span>
          </div>
        ))}

      </div>
    </div>
  );
};
