import React from "react";

interface ArticleCardProps {
  title: string;
  price: number;
  currency: "MGA" | "USDT";
  imageUrl: string;
  sellerName: string;
  sellerAvatar: string;
  isSellerVerified: boolean;
  isBoosted: boolean;
  hasDeliverySubscription: boolean;
  onBuyClick: () => void;
}

export const ArticleCard: React.FC<ArticleCardProps> = ({
  title,
  price,
  currency,
  imageUrl,
  sellerName,
  sellerAvatar,
  isSellerVerified,
  isBoosted,
  hasDeliverySubscription,
  onBuyClick,
}) => {
  
  // Formatage propre du prix en Ariary sans fioritures complexes
  const formattedPrice = currency === "MGA" 
    ? `${price.toLocaleString('fr-FR')} Ar` 
    : `${price} USDT`;

  return (
    <div 
      className={`relative group rounded-3xl overflow-hidden transition-all duration-300 backdrop-blur-xl border
        ${isBoosted 
          ? 'bg-white/[0.08] border-yellow-500/40 shadow-glow-boost' 
          : 'bg-white/[0.04] border-white/[0.12] shadow-glass hover:shadow-glass-hover hover:bg-white/[0.07]'
        }`}
    >
      {/* Badge "BOOSTÉ" discret et élégant si applicable */}
      {isBoosted && (
        <span className="absolute top-3 left-3 z-10 text-[10px] font-bold tracking-widest uppercase px-2.5 py-1 rounded-full bg-gradient-to-r from-yellow-500 to-amber-600 text-black shadow-lg">
          🔥 Boosté
        </span>
      )}

      {/* Image de l'article avec effet de zoom doux au survol */}
      <div className="relative aspect-[4/5] w-full overflow-hidden bg-black/20">
        <img 
          src={imageUrl} 
          alt={title} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        
        {/* Badge livraison gratuite si le vendeur paye l'abonnement partenaire */}
        {hasDeliverySubscription && (
          <div className="absolute bottom-3 left-3 px-3 py-1 text-xs rounded-xl backdrop-blur-md bg-cyan-500/20 border border-cyan-400/30 text-cyan-200 font-medium flex items-center gap-1">
            🛵 Livraison incluse
          </div>
        )}
      </div>

      {/* Zone Infos / Contenu (Verre pur) */}
      <div className="p-4 space-y-3">
        {/* Infos Vendeur */}
        <div className="flex items-center gap-2">
          <img 
            src={sellerAvatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=80&q=80"} 
            alt={sellerName} 
            className="w-6 h-6 rounded-full object-cover border border-white/20"
          />
          <span className="text-xs text-white/70 font-medium truncate flex items-center gap-1">
            {sellerName}
            {isSellerVerified && (
              <span className="text-emerald-400 title='Vendeur Vérifié' text-[10px]">🟢</span>
            )}
          </span>
        </div>

        {/* Titre et Prix de l'article */}
        <div className="flex items-end justify-between gap-2">
          <div className="truncate">
            <h3 className="text-sm font-semibold text-white/90 truncate group-hover:text-white transition-colors">
              {title}
            </h3>
            <p className="text-lg font-bold bg-gradient-to-r from-white to-white/80 bg-clip-text text-transparent">
              {formattedPrice}
            </p>
          </div>

          {/* Bouton d'Achat fluide effet gel liquide */}
          <button 
            onClick={onBuyClick}
            className="px-4 py-2 text-xs font-bold uppercase tracking-wider text-white rounded-2xl transition-all duration-300
              bg-gradient-to-r from-purple-500/40 to-pink-500/40 border border-white/20 backdrop-blur-md
              hover:from-purple-500/60 hover:to-pink-500/60 hover:scale-[1.03] active:scale-[0.98] shadow-md shadow-purple-950/20"
          >
            Acheter
          </button>
        </div>
      </div>
    </div>
  );
};
