"use client";

import React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";

export const BottomNav = () => {
  const pathname = usePathname();

  const navItems = [
    { label: "Accueil", path: "/", icon: "🛍️" },
    { label: "Vendre", path: "/publish", icon: "➕" },
    { label: "Mon Pro", path: "/dashboard", icon: "📊" },
    { label: "Profil", path: "/profile", icon: "👤" }, // AJOUT DE L'ONGLET PROFIL
  ];

  return (
    <div className="fixed bottom-4 left-1/2 -translate-x-1/2 w-[calc(100%-2rem)] max-w-sm z-50">
      <nav className="flex items-center justify-around py-3 px-2 rounded-2xl bg-white/[0.04] backdrop-blur-xl border border-white/[0.1] shadow-glass">
        {navItems.map((item) => {
          const isActive = pathname === item.path;
          
          return (
            <Link 
              key={item.path} 
              href={item.path}
              className="flex flex-col items-center gap-1 flex-1 group transition-all"
            >
              <span className={`text-lg transition-transform duration-200 group-hover:scale-110
                ${isActive ? "drop-shadow-[0_0_8px_rgba(168,85,247,0.6)]" : "opacity-60"}`}
              >
                {item.icon}
              </span>
              <span className={`text-[10px] font-bold tracking-wide transition-colors
                ${isActive ? "text-purple-400" : "text-white/40 group-hover:text-white/60"}`}
              >
                {item.label}
              </span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
};
