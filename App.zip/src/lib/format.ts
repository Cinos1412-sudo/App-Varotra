/**
 * Formate proprement un prix en Ariary (MGA) ou en USDT
 */
export function formatCurrency(amount: number, currency: "MGA" | "USDT"): string {
  if (currency === "MGA") {
    return `${amount.toLocaleString("fr-FR")} Ar`;
  }
  return `${amount.toLocaleString("en-US", { minimumFractionDigits: 2 })} USDT`;
}

/**
 * Formate un timestamp Convex en date lisible (ex: "7 juil. à 18:40")
 */
export function formatDateTime(timestamp: number): string {
  return new Date(timestamp).toLocaleDateString("fr-FR", {
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}