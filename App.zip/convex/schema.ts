import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  // ==========================================
  // 1. UTILISATEURS / VENDEURS / ACHETEURS
  // ==========================================
  users: defineTable({
    clerkId: v.string(),             // ID unique du fournisseur d'authentification
    username: v.string(),            // Pseudo de l'utilisateur
    email: v.string(),               // Adresse email
    phone: v.optional(v.string()),   // Numéro de téléphone (crucial pour le Mobile Money)
    avatarUrl: v.string(),           // URL de la photo de profil
    
    // Système de Vérification des Vendeurs (Badge Vert)
    isVerified: v.boolean(),         // Statut de confiance accordé par l'admin
    verificationStatus: v.union(
      v.literal("NOT_STARTED"),
      v.literal("PENDING"),
      v.literal("VERIFIED"),
      v.literal("REJECTED")
    ),
    idCardUrl: v.optional(v.string()), // URL du scan de la CIN pour validation admin

    // Système d'Abonnement Livraison Partenaire (Côté Vendeur)
    isSubscribedToDelivery: v.boolean(),
    subscriptionValidUntil: v.optional(v.number()), // Date d'expiration en millisecondes (Timestamp)
    
    // Porte-monnaie interne (Gestion financière et commissions)
    withdrawableBalance: v.number(), // Argent net disponible pour le retrait vers Mobile Money
    pendingBalance: v.number(),      // Argent bloqué en Escrow (attente de livraison)
  })
  .index("by_clerkId", ["clerkId"])
  .index("by_verificationStatus", ["verificationStatus"]),

  // ==========================================
  // 2. ARTICLES / PRODUITS (Style Vinted)
  // ==========================================
  articles: defineTable({
    sellerId: v.id("users"),         // Lien vers le vendeur
    title: v.string(),               // Nom de l'article
    description: v.string(),         // Description de l'état/taille/détails
    price: v.number(),               // Prix brut affiché
    currency: v.union(v.literal("MGA"), v.literal("USDT")), // Ariary ou Crypto
    images: v.array(v.string()),     // Liste des URLs des photos du produit
    category: v.string(),            // Catégorie (Fripe Homme, Robe, Chaussures, etc.)
    status: v.union(
      v.literal("AVAILABLE"),        // En vente
      v.literal("PENDING_ESCROW"),   // Achat initié, article bloqué temporairement
      v.literal("SOLD")              // Vendu définitivement
    ),
    
    // Système de Visibilité Payante (Boost)
    isBoosted: v.boolean(),          // True si le vendeur a payé un boost
    boostedUntil: v.optional(v.number()), // Fin de la mise en avant (Timestamp)
    createdAt: v.number(),           // Date de publication
  })
  .index("by_sellerId", ["sellerId"])
  .index("by_status_and_boost", ["status", "isBoosted"])
  .index("by_createdAt", ["createdAt"]),

  // ==========================================
  // 3. STORIES ÉPHÉMÈRES (Style Instagram)
  // ==========================================
  stories: defineTable({
    sellerId: v.id("users"),         // Créateur de la story
    imageUrl: v.string(),            // Visuel de la story
    articleId: v.optional(v.id("articles")), // Lien direct vers un article pour cliquer et acheter
    createdAt: v.number(),           // Moment de création
    expiresAt: v.number(),           // Suppression logique après 24 heures (createdAt + 24h)
  })
  .index("by_expiresAt", ["expiresAt"])
  .index("by_sellerId", ["sellerId"]),

  // ==========================================
  // 4. MESSAGERIE ET CHAT EN TEMPS RÉEL
  // ==========================================
  conversations: defineTable({
    buyerId: v.id("users"),          // Acheteur intéressé
    sellerId: v.id("users"),         // Vendeur de l'article
    articleId: v.id("articles"),     // Lié à un contexte d'article précis
    lastMessageTimestamp: v.number(),// Pour trier la liste des discussions récentes
  })
  .index("by_participants", ["buyerId", "sellerId"])
  .index("by_articleId", ["articleId"]),

  messages: defineTable({
    conversationId: v.id("conversations"),
    senderId: v.id("users"),         // Qui envoie le message
    text: v.string(),                // Message texte standard ou notification
    
    // Typage spécial pour la capture d'écran de paiement et la détection OCR
    type: v.union(
      v.literal("TEXT"),
      v.literal("PAYMENT_SCREENSHOT"), // Capture d'écran du transfert envoyée par l'acheteur
      v.literal("SYSTEM_NOTIFICATION") // Notification automatique gérée par l’application
    ),
    screenshotUrl: v.optional(v.string()), // URL de l'image stockée si c'est un screenshot
    ocrProcessed: v.optional(v.boolean()),  // Indique si l'IA a scanné le reçu
    ocrConfidence: v.optional(v.number()), // Taux de certitude du scan (ex: 0.95)
  })
  .index("by_conversationId", ["conversationId"]),

  // ==========================================
  // 5. SECURE ESCROW (Tiers de Confiance)
  // ==========================================
  escrowTransactions: defineTable({
    articleId: v.id("articles"),
    buyerId: v.id("users"),
    sellerId: v.id("users"),
    
    // Gestion des flux financiers et des retenues (Commissions)
    amount: v.number(),                     // Montant brut versé par l'acheteur
    commissionAmount: v.optional(v.number()),// Commission retenue par App'Varotra
    sellerNetPayout: v.optional(v.number()), // Montant net qui sera versé au vendeur (Brut - Commission)
    currency: v.union(v.literal("MGA"), v.literal("USDT")),
    
    status: v.union(
      v.literal("INITIATED"),            // Acheteur a cliqué sur "Acheter"
      v.literal("SCREENSHOT_SUBMITTED"),  // Reçu envoyé, en attente de validation OCR ou humaine
      v.literal("FUNDS_HELD"),           // Fonds validés et bloqués de manière sécurisée par l'app
      v.literal("DELIVERED"),            // Colis remis (en RDV ou via le livreur abonné)
      v.literal("RELEASED"),             // Fonds libérés avec succès sur le portefeuille du vendeur
      v.literal("DISPUTED"),             // Litige ouvert (problème lors du RDV ou livraison)
      v.literal("REFUNDED")              // Transaction annulée et acheteur remboursé
    ),
    
    paymentMethod: v.union(
      v.literal("MVOLA"),
      v.literal("ORANGE_MONEY"),
      v.literal("AIRTEL_MONEY"),
      v.literal("CRYPTO_USDT")
    ),
    transactionReference: v.optional(v.string()), // Code de transaction extrait par l'OCR
    createdAt: v.number(),
    updatedAt: v.number(),
  })
  .index("by_status", ["status"])
  .index("by_buyerId", ["buyerId"])
  .index("by_sellerId", ["sellerId"])
  .index("by_articleId", ["articleId"]),

  // ==========================================
  // 6. FACTURATION (Génération de Factures)
  // ==========================================
  invoices: defineTable({
    escrowId: v.id("escrowTransactions"), // Lié à la vente sécurisée
    sellerId: v.id("users"),              // Vendeur facturé
    invoiceNumber: v.string(),            // Identifiant unique (ex: AV-2026-XXXXXX)
    grossAmount: v.number(),              // Prix total de la vente
    commissionAmount: v.number(),         // Part prélevée par App'Varotra
    netAmount: v.number(),                // Part nette créditée au vendeur
    createdAt: v.number(),                // Date d'émission de la facture
  })
  .index("by_sellerId", ["sellerId"]),
});
