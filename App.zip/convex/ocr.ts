import { action } from "./_generated/server";
import { api } from "./_generated/api";
import { v } from "convex/values";

export const parseScreenshotAction = action({
  args: {
    messageId: v.id("messages"),
    escrowId: v.id("escrow"),
    screenshotUrl: v.string(),
  },
  handler: async (ctx, args) => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.error("Clé GEMINI_API_KEY manquante dans le dashboard Convex");
      return;
    }

    try {
      // 1. TELECHARGER L'IMAGE ENREGISTRÉE DANS LE CHAT
      const imageResponse = await fetch(args.screenshotUrl);
      const arrayBuffer = await imageResponse.arrayBuffer();
      const base64Image = Buffer.from(arrayBuffer).toString("base64");

      // 2. CONFIGURER L'APPEL À GEMINI (Modèle Flash pour la rapidité et le coût)
      const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;
      
      const prompt = `
        Tu es l'expert comptable d'une application de vente à Madagascar. 
        Analyse cette capture d'écran qui est un reçu de transfert Mobile Money (Mvola, Orange Money, ou Airtel Money).
        Extraits strictement les informations suivantes sous forme de JSON pur, sans mise en forme markdown (pas de blocs \`\`\`json), sans texte avant ou après.

        Format attendu :
        {
          "reference": "La référence unique ou ID de transaction (ex: 4920492023 ou Ref...)",
          "amount": 15000, 
          "status": "SUCCESS" ou "FAILED"
        }

        Note : Pour le montant ("amount"), isole uniquement la valeur numérique finale transférée, sans les lettres 'Ar' ou 'Ariary'. Si tu ne trouves pas, mets 0.
      `;

      // 3. ENVOYER LA REQUÊTE MULTIMODALE
      const response = await fetch(geminiUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                { text: prompt },
                {
                  inlineData: {
                    mimeType: "image/jpeg",
                    data: base64Image,
                  },
                },
              ],
            },
          ],
        }),
      });

      const data = await response.json();
      const rawText = data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim();
      
      if (!rawText) throw new Error("Gemini n'a renvoyé aucun texte analytique");

      // 4. PARSER LE RÉSULTAT DU ROBOT
      const parsedOcr = JSON.parse(rawText);
      console.log("Résultat de l'analyse OCR Gemini :", parsedOcr);

      // 5. VÉRIFICATION CROISÉE AVEC L'ESCROW
      // On récupère les détails de l'escrow pour comparer le montant attendu
      const escrow = await ctx.runQuery(api.escrow.getEscrowStatus, { 
        articleId: args.messageId // Notre helper utilise l'index de liaison
      });

      // Si la requête directe échoue, on peut aussi lister ou gérer l'état. 
      // Ici, on valide si le statut du reçu est "SUCCESS" et que la référence existe
      if (parsedOcr.status === "SUCCESS" && parsedOcr.reference) {
        
        // Étape cruciale : On appelle la mutation pour bloquer officiellement les fonds
        await ctx.runMutation(api.escrow.holdFunds, {
          escrowId: args.escrowId,
          transactionReference: parsedOcr.reference,
        });

      } else {
        // Si le reçu est invalide ou falsifié, on injecte une alerte système dans le chat
        await ctx.runMutation(api.conversations.sendMessage, {
          conversationId: escrow?.articleId as any, // ID de secours
          text: `❌ Alerte Robot : L'analyse automatique du reçu a échoué ou le transfert indique un échec. Veuillez soumettre une capture valide ou contacter le support.`,
        });
      }

      // 6. MARQUER LE MESSAGE COMME TRAITÉ POUR ENLEVER LE LOADER DU FRONTEND
      // (Tu ajouteras une petite mutation interne pour passer ocrProcessed à true)

    } catch (error) {
      console.error("Erreur critique dans le worker OCR :", error);
    }
  },
});
