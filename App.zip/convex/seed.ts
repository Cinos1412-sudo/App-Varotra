import { mutation } from "./_generated/server";

export const seedDatabase = mutation({
  args: {},
  handler: async (ctx) => {
    // 1. Nettoyer la base pour éviter les doublons au cours des tests
    const existingUsers = await ctx.db.query("users").collect();
    for (const u of existingUsers) await ctx.db.delete(u._id);
    
    const existingArticles = await ctx.db.query("articles").collect();
    for (const a of existingArticles) await ctx.db.delete(a._id);

    const existingStories = await ctx.db.query("stories").collect();
    for (const s of existingStories) await ctx.db.delete(s._id);

    console.log("♻️ Base de données nettoyée.");

    // 2. CRÉATION DE DEUX FAUX VENDEURS STARS À MADA
    const seller1Id = await ctx.db.insert("users", {
      clerkId: "mock_user_rindra",
      username: "Rindra_Fripe",
      email: "rindra@varotra.mg",
      phone: "+261340000001",
      avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80",
      isVerified: true,
      verificationStatus: "VERIFIED",
      isSubscribedToDelivery: true, // Livraison gratuite incluse !
      withdrawableBalance: 45000,
      pendingBalance: 0,
    });

    const seller2Id = await ctx.db.insert("users", {
      clerkId: "mock_user_toky",
      username: "Toky_Tech",
      email: "toky@tech.mg",
      phone: "+261320000002",
      avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80",
      isVerified: false,
      verificationStatus: "NOT_STARTED",
      isSubscribedToDelivery: false,
      withdrawableBalance: 0,
      pendingBalance: 120000,
    });

    // 3. INJECTION D'ARTICLES (Friperie et Tech)
    // Article 1 : Normal
    await ctx.db.insert("articles", {
      sellerId: seller1Id,
      title: "Robe d'été Vintage",
      description: "Très bon état, fripe de premier choix venant d'Europe. Disponible sur Tana.",
      price: 25000,
      currency: "MGA",
      images: ["https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?auto=format&fit=crop&w=500&q=80"],
      category: "Mode",
      status: "AVAILABLE",
      isBoosted: false,
      createdAt: Date.now(),
    });

    // Article 2 : BOOSTÉ (S'affichera en premier avec une lueur dorée)
    await ctx.db.insert("articles", {
      sellerId: seller2Id,
      title: "Casque Audio Sony WH",
      description: "Réduction de bruit active. Vente urgente pour cause de départ. Prix sacrifié.",
      price: 450000,
      currency: "MGA",
      images: ["https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=500&q=80"],
      category: "Électronique",
      status: "AVAILABLE",
      isBoosted: true,
      boostedUntil: Date.now() + 24 * 60 * 60 * 1000, // Boosté pour 24h
      createdAt: Date.now(),
    });

    // 4. INJECTION D'UNE STORY VISIBLE
    await ctx.db.insert("stories", {
      sellerId: seller1Id,
      imageUrl: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=500&q=80",
      createdAt: Date.now(),
      expiresAt: Date.now() + 24 * 60 * 60 * 1000,
    });

    console.log("✅ Seed complété avec succès ! Faux profils, articles et stories injectés.");
  },
});