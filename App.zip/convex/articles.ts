import { mutation, query } from "./_generated/server";
import { v } from "convex/values";

// AJOUT : CREER UN ARTICLE DEPUIS LE FORMULAIRE
export const createArticle = mutation({
  args: {
    title: v.string(),
    description: v.string(),
    price: v.number(),
    currency: v.union(v.literal("MGA"), v.literal("USDT")),
    images: v.array(v.string()),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new Error("Non authentifié");

    const user = await ctx.db
      .query("users")
      .withIndex("by_clerkId", (q) => q.eq("clerkId", identity.subject))
      .unique();
    if (!user) throw new Error("Utilisateur introuvable");

    return await ctx.db.insert("articles", {
      sellerId: user._id,
      title: args.title,
      description: args.description,
      price: args.price,
      currency: args.currency,
      images: args.images,
      category: "Mode", // Par défaut pour le MVP
      status: "AVAILABLE",
      isBoosted: false,
      createdAt: Date.now(),
    });
  },
});

// A. BOOSTER UN ARTICLE (Mise en avant payante pendant X heures)
export const boostArticle = mutation({
  args: {
    articleId: v.id("articles"),
    durationInHours: v.number(), // Ex: 24, 48 ou 72 heures
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new Error("Non authentifié");

    const user = await ctx.db
      .query("users")
      .withIndex("by_clerkId", (q) => q.eq("clerkId", identity.subject))
      .unique();
    if (!user) throw new Error("Utilisateur introuvable");

    const article = await ctx.db.get(args.articleId);
    if (!article || article.sellerId !== user._id) {
      throw new Error("Article introuvable ou vous n'en êtes pas le propriétaire");
    }

    const boostDurationMs = args.durationInHours * 60 * 60 * 1000;
    const now = Date.now();

    // Calcul de la fin du boost (on ajoute au boost existant si l'article est déjà boosté)
    const currentBoostUntil = article.boostedUntil ?? now;
    const baseTime = currentBoostUntil > now ? currentBoostUntil : now;
    const newBoostUntil = baseTime + boostDurationMs;

    // Appliquer le boost en base de données
    await ctx.db.patch(args.articleId, {
      isBoosted: true,
      boostedUntil: newBoostUntil,
    });

    return { success: true, boostedUntil: newBoostUntil };
  },
});

// B. LE FEED PRINCIPAL : Récupérer les articles disponibles (Boostés d'abord !)
export const getFeedArticles = query({
  args: {},
  handler: async (ctx) => {
    const now = Date.now();

    // 1. On récupère d'un coup tous les articles disponibles
    const allAvailable = await ctx.db
      .query("articles")
      .withIndex("by_status_and_boost", (q) => q.eq("status", "AVAILABLE"))
      .order("desc")
      .collect();

    // 2. On sépare et on trie à la volée : les boostés actifs d'abord, le reste après
    const boostedArticles = allAvailable.filter(
      (art) => art.isBoosted && art.boostedUntil && art.boostedUntil > now
    );
    const regularArticles = allAvailable.filter(
      (art) => !art.isBoosted || !art.boostedUntil || art.boostedUntil <= now
    );

    // Concaténer pour avoir les prioritaires au début de la liste
    const sortedFeed = [...boostedArticles, ...regularArticles];

    // Enrichir avec les données du vendeur pour éviter au frontend de refaire des requêtes
    return await Promise.all(
      sortedFeed.map(async (article) => {
        const seller = await ctx.db.get(article.sellerId);
        return {
          ...article,
          sellerName: seller?.username ?? "Boutique",
          sellerAvatar: seller?.avatarUrl ?? "",
          isSellerVerified: seller?.isVerified ?? false,
          hasDeliverySubscription: seller?.isSubscribedToDelivery ?? false,
        };
      })
    );
  },
});
