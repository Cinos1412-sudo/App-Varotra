import { mutation, query } from "./_generated/server";
import { v } from "convex/values";

// ====================================================
// 1. INITIALISER LA TRANSACTION (Clic sur "Acheter")
// ====================================================
export const initiateTransaction = mutation({
  args: {
    articleId: v.id("articles"),
    paymentMethod: v.union(
      v.literal("MVOLA"),
      v.literal("ORANGE_MONEY"),
      v.literal("AIRTEL_MONEY"),
      v.literal("USDT")
    ),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new Error("Non autorisé");

    // A. Récupérer l'acheteur et l'article
    const buyer = await ctx.db
      .query("users")
      .withIndex("by_clerkId", (q) => q.eq("clerkId", identity.subject))
      .unique();
    if (!buyer) throw new Error("Acheteur introuvable");

    const article = await ctx.db.get(args.articleId);
    if (!article) throw new Error("Article introuvable");
    if (article.status !== "AVAILABLE") throw new Error("Cet article n'est plus disponible");
    if (article.sellerId === buyer._id) throw new Error("Vous ne pouvez pas acheter votre propre article");

    // B. Créer la conversation dédiée si elle n'existe pas déjà
    let conversation = await ctx.db
      .query("conversations")
      .filter((q) => 
        q.and(
          q.eq(q.field("articleId"), args.articleId),
          q.eq(q.field("buyerId"), buyer._id)
        )
      )
      .unique();

    if (!conversation) {
      conversation = await ctx.db.insert("conversations", {
        articleId: args.articleId,
        buyerId: buyer._id,
        sellerId: article.sellerId,
        lastMessageTimestamp: Date.now(),
      });
    }

    // C. Verrouiller l'article (Statut PENDING pour éviter les doublons)
    await ctx.db.patch(args.articleId, { status: "PENDING" });

    // D. Créer la session d'Escrow (Séquestre)
    const escrowId = await ctx.db.insert("escrow", {
      articleId: args.articleId,
      buyerId: buyer._id,
      sellerId: article.sellerId,
      amount: article.price,
      status: "INITIATED",
      paymentMethod: args.paymentMethod,
    });

    // E. Envoyer un message système automatique dans le chat
    await ctx.db.insert("messages", {
      conversationId: conversation._id,
      senderId: buyer._id, // Assigné arbitrairement à l'acheteur pour le flux
      text: `🤖 Système : Demande d'achat initiée via ${args.paymentMethod}. Veuillez envoyer exactement ${article.price.toLocaleString("fr-FR")} Ar et soumettre la capture d'écran du reçu.`,
      type: "SYSTEM_NOTIFICATION",
    });

    return { escrowId, conversationId: conversation._id };
  },
});

// ====================================================
// 2. SOUMETTRE LA CAPTURE D'ÉCRAN DU PAIEMENT
// ====================================================
export const submitPaymentScreenshot = mutation({
  args: {
    escrowId: v.id("escrow"),
    conversationId: v.id("conversations"),
    screenshotUrl: v.string(),
  },
  handler: async (ctx, args) => {
    const escrow = await ctx.db.get(args.escrowId);
    if (!escrow || escrow.status !== "INITIATED") {
      throw new Error("Action impossible dans l'état actuel de la transaction");
    }

    // Mettre à jour le statut de l'escrow
    await ctx.db.patch(args.escrowId, {
      status: "SCREENSHOT_SUBMITTED",
      screenshotUrl: args.screenshotUrl,
    });

    // Insérer la capture comme un message spécial dans le chat
    const messageId = await ctx.db.insert("messages", {
      conversationId: args.conversationId,
      senderId: escrow.buyerId,
      text: "Capture d'écran du reçu Mobile Money soumise.",
      type: "PAYMENT_SCREENSHOT",
      screenshotUrl: args.screenshotUrl,
      ocrProcessed: false,
    });

    return { messageId };
  },
});

// ====================================================
// 3. SEQUESTRER LES FONDS (Appelé automatiquement après validation OCR ou Admin)
// ====================================================
export const holdFunds = mutation({
  args: {
    escrowId: v.id("escrow"),
    transactionReference: v.string(),
  },
  handler: async (ctx, args) => {
    const escrow = await ctx.db.get(args.escrowId);
    if (!escrow || escrow.status !== "SCREENSHOT_SUBMITTED") return;

    // A. Mettre à jour l'escrow
    await ctx.db.patch(args.escrowId, {
      status: "FUNDS_HELD",
      transactionReference: args.transactionReference,
    });

    // B. Créditer virtuellement la balance en attente (pending) du vendeur
    const seller = await ctx.db.get(escrow.sellerId);
    if (seller) {
      await ctx.db.patch(escrow.sellerId, {
        pendingBalance: (seller.pendingBalance ?? 0) + escrow.amount,
      });
    }

    // C. Notifier les utilisateurs dans le chat
    const conversation = await ctx.db
      .query("conversations")
      .filter((q) => q.eq(q.field("articleId"), escrow.articleId))
      .first();

    if (conversation) {
      await ctx.db.insert("messages", {
        conversationId: conversation._id,
        senderId: escrow.sellerId,
        text: `🟢 Tiers de Confiance : Paiement vérifié (Réf: ${args.transactionReference}). L'argent est sécurisé au séquestre d'App'Varotra. Vendeur, vous pouvez livrer le colis !`,
        type: "SYSTEM_NOTIFICATION",
      });
    }
  },
});

// ====================================================
// 4. LIBÉRER LES FONDS AU VENDEUR (Validation Acheteur)
// ====================================================
export const releaseFunds = mutation({
  args: { escrowId: v.id("escrow") },
  handler: async (ctx, args) => {
    const escrow = await ctx.db.get(args.escrowId);
    if (!escrow || escrow.status !== "FUNDS_HELD") {
      throw new Error("Les fonds ne sont pas dans un état sécurisé libérable");
    }

    // A. Calcul de ta commission de 5%
    const platformCommission = Math.round(escrow.amount * 0.05);
    const sellerNetGain = escrow.amount - platformCommission;

    const seller = await ctx.db.get(escrow.sellerId);
    if (!seller) throw new Error("Vendeur introuvable");

    // B. Transfert financier interne
    // Déduire du solde en attente, ajouter au solde disponible réel (moins ta commission)
    await ctx.db.patch(escrow.sellerId, {
      pendingBalance: Math.max(0, (seller.pendingBalance ?? 0) - escrow.amount),
      withdrawableBalance: (seller.withdrawableBalance ?? 0) + sellerNetGain,
    });

    // C. Clôturer l'escrow et marquer l'article comme définitivement vendu
    await ctx.db.patch(args.escrowId, { status: "RELEASED" });
    await ctx.db.patch(escrow.articleId, { status: "SOLD" });

    // D. Message de clôture dans le chat
    const conversation = await ctx.db
      .query("conversations")
      .filter((q) => q.eq(q.field("articleId"), escrow.articleId))
      .first();

    if (conversation) {
      await ctx.db.insert("messages", {
        conversationId: conversation._id,
        senderId: escrow.buyerId,
        text: `🎉 Transaction réussie ! Le vendeur a reçu ${sellerNetGain.toLocaleString("fr-FR")} Ar (Frais de service d'intermédiation de 5% déduits). Merci d'avoir utilisé App'Varotra !`,
        type: "SYSTEM_NOTIFICATION",
      });
    }

    return { success: true };
  },
});

// ====================================================
// 5. DÉCLARER UN LITIGE (En cas de problème de livraison)
// ====================================================
export const openDispute = mutation({
  args: { escrowId: v.id("escrow"), reason: v.string() },
  handler: async (ctx, args) => {
    const escrow = await ctx.db.get(args.escrowId);
    if (!escrow || escrow.status !== "FUNDS_HELD") {
      throw new Error("Impossible d'ouvrir un litige à ce stade");
    }

    // Passer en mode gel total pour arbitrage manuel
    await ctx.db.patch(args.escrowId, { status: "DISPUTED" });

    const conversation = await ctx.db
      .query("conversations")
      .filter((q) => q.eq(q.field("articleId"), escrow.articleId))
      .first();

    if (conversation) {
      await ctx.db.insert("messages", {
        conversationId: conversation._id,
        senderId: escrow.buyerId,
        text: `⚠️ LITIGE OUVERT par l'acheteur. Motif : "${args.reason}". Les fonds restent bloqués par la plateforme jusqu'à l'intervention de notre support client.`,
        type: "SYSTEM_NOTIFICATION",
      });
    }

    return { success: true };
  },
});

// ====================================================
// 6. SUIVI DU STATUT (Pour l'interface utilisateur)
// ====================================================
export const getEscrowStatus = query({
  args: { articleId: v.id("articles") },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("escrow")
      .withIndex("by_articleId", (q) => q.eq("articleId", args.articleId))
      .first();
  },
});
