export default {
  providers: [
    {
      // Récupère l'URL configurée dans le tableau de bord Convex
      domain: process.env.CLERK_JWT_ISSUER_DOMAIN,
      applicationID: "convex",
    },
  ],
};
