import { mutation, query } from "./_generated/server";
import { v } from "convex/values";

// A. LISTER TOUTES MES CONVERSATIONS ACTIVES (Boîte de réception)
export const getMyConversations = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return [];

    const user = await ctx.db
      .query("users")
      .withIndex("by_clerkId", (q) => q.eq("clerkId", identity.subject))
      .unique();
    if (!user) return [];

    // Récupérer les convs où l'utilisateur est soit acheteur, soit vendeur
    const conversations = await ctx.db
      .query("conversations")
      .order("desc")
      .collect();

    const myConvs = conversations.filter(
      (c) => c.buyerId === user._id || c.sellerId === user._id
    );

    // Enrichir chaque ligne avec les détails de l'autre participant et de l'article
    return await Promise.all(
      myConvs.map(async (conv) => {
        const isBuyer = conv.buyerId === user._id;
        const otherParticipantId = isBuyer ? conv.sellerId : conv.buyerId;
        
        const otherUser = await ctx.db.get(otherParticipantId);
        const article = await ctx.db.get(conv.articleId);

        // Récupérer le tout dernier message pour l'aperçu dans la liste
        const lastMessage = await ctx.db
          .query("messages")
          .withIndex("by_conversationId", (q) => q.eq("conversationId", conv._id))
          .order("desc")
          .first();

        return {
          id: conv._id,
          articleTitle: article?.title ?? "Article supprimé",
          articlePrice: article?.price ?? 0,
          articleImage: article?.images[0] ?? "",
          otherUserName: otherUser?.username ?? "Utilisateur",
          otherUserAvatar: otherUser?.avatarUrl ?? "",
          isOtherUserVerified: otherUser?.isVerified ?? false,
          lastMessageText: lastMessage?.text ?? "Aucun message",
          lastMessageTime: conv.lastMessageTimestamp,
        };
      })
    );
  },
});

// B. CHARGER LES MESSAGES D'UN CHAT PRÉCIS
export const getMessages = query({
  args: { conversationId: v.id("conversations") },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("messages")
      .withIndex("by_conversationId", (q) => q.eq("conversationId", args.conversationId))
      .order("asc") // Du plus ancien au plus récent
      .collect();
  },
});

// C. ENVOYER UN MESSAGE TEXTE STANDARD
export const sendMessage = mutation({
  args: {
    conversationId: v.id("conversations"),
    text: v.string(),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new Error("Non authentifié");

    const user = await ctx.db
      .query("users")
      .withIndex("by_clerkId", (q) => q.eq("clerkId", identity.subject))
      .unique();
    if (!user) throw new Error("Utilisateur introuvable");

    const now = Date.now();

    // Insérer le message
    const messageId = await ctx.db.insert("messages", {
      conversationId: args.conversationId,
      senderId: user._id,
      text: args.text,
      type: "TEXT",
    });

    // Mettre à jour le timestamp de la conversation pour la faire remonter en haut de la liste
    await ctx.db.patch(args.conversationId, {
      lastMessageTimestamp: now,
    });

    return messageId;
  },
});
