import { mutation, query } from "./_generated/server";
import { v } from "convex/values";

const TWENTY_FOUR_HOURS = 24 * 60 * 60 * 1000;

// RETOUCHE : PUBLIER UNE STORY ALIGNÉE SUR LE FRONTEND
export const addStory = mutation({
  args: {
    mediaUrl: v.string(),
    mediaType: v.string(), // Reçu du frontend, on l'ignore ou l'adapte
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new Error("Non authentifié");

    const user = await ctx.db
      .query("users")
      .withIndex("by_clerkId", (q) => q.eq("clerkId", identity.subject))
      .unique();
    if (!user) throw new Error("Utilisateur introuvable");

    const now = Date.now();

    return await ctx.db.insert("stories", {
      sellerId: user._id,
      imageUrl: args.mediaUrl,
      createdAt: now,
      expiresAt: now + TWENTY_FOUR_HOURS,
    });
  },
});

// ... (garde ton ancienne fonction getActiveStories ici)

// B. RÉCUPÉRER TOUTES LES STORIES ACTIVES (Style Instagram)
// Filtre les stories expirées et les regroupe idéalement côté frontend par vendeur
export const getActiveStories = query({
  args: {},
  handler: async (ctx) => {
    const now = Date.now();

    // Récupérer les stories dont la date d'expiration est dans le futur
    const activeStories = await ctx.db
      .query("stories")
      .withIndex("by_expiresAt")
      .filter((q) => q.gt(q.field("expiresAt"), now))
      .order("desc")
      .collect();

    // Pour chaque story, on récupère les infos basiques du vendeur (Nom, Avatar) pour l'affichage
    const storiesWithSellerInfo = await Promise.all(
      activeStories.map(async (story) => {
        const seller = await ctx.db.get(story.sellerId);
        return {
          ...story,
          sellerName: seller?.username ?? "Vendeur Anonyme",
          sellerAvatar: seller?.avatarUrl ?? "",
          isSellerVerified: seller?.isVerified ?? false,
        };
      })
    );

    return storiesWithSellerInfo;
  },
});
