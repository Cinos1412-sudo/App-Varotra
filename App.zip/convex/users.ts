import { mutation, query } from "./_generated/server";
import { v } from "convex/values";

// A. SYNCHRONISER L'UTILISATEUR (Appelé à la connexion/inscription)
export const syncUser = mutation({
  args: {
    username: v.string(),
    email: v.string(),
    avatarUrl: v.string(),
    phone: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new Error("Non autorisé");

    const existingUser = await ctx.db
      .query("users")
      .withIndex("by_clerkId", (q) => q.eq("clerkId", identity.subject))
      .unique();

    if (existingUser) {
      // Mettre à jour si le profil a changé (ex: nouvel avatar)
      await ctx.db.patch(existingUser._id, {
        username: args.username,
        avatarUrl: args.avatarUrl,
        phone: args.phone ?? existingUser.phone,
      });
      return existingUser._id;
    }

    // Créer un nouvel utilisateur avec des balances à zéro
    return await ctx.db.insert("users", {
      clerkId: identity.subject,
      username: args.username,
      email: args.email,
      avatarUrl: args.avatarUrl,
      phone: args.phone,
      isVerified: false,
      verificationStatus: "NOT_STARTED",
      isSubscribedToDelivery: false,
      withdrawableBalance: 0,
      pendingBalance: 0,
    });
  },
});

// B. RÉCUPÉRER MON PROFIL ET MES BALANCES
export const getMe = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return null;

    return await ctx.db
      .query("users")
      .withIndex("by_clerkId", (q) => q.eq("clerkId", identity.subject))
      .unique();
    },
});

// C. DEMANDER LA VÉRIFICATION (Soumettre la CIN pour le badge vert)
export const requestVerification = mutation({
  args: { idCardUrl: v.string() },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new Error("Non authentifié");

    const user = await ctx.db
      .query("users")
      .withIndex("by_clerkId", (q) => q.eq("clerkId", identity.subject))
      .unique();
    if (!user) throw new Error("Utilisateur introuvable");

    await ctx.db.patch(user._id, {
      verificationStatus: "PENDING",
      idCardUrl: args.idCardUrl,
    });

    return { success: true };
  },
});

// D. S'ABONNER À LA LIVRAISON PARTENAIRE (Forfait 30 jours)
export const subscribeToDelivery = mutation({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new Error("Non authentifié");

    const user = await ctx.db
      .query("users")
      .withIndex("by_clerkId", (q) => q.eq("clerkId", identity.subject))
      .unique();
    if (!user) throw new Error("Utilisateur introuvable");

    const activeUntil = Date.now() + 30 * 24 * 60 * 60 * 1000; // +30 jours

    await ctx.db.patch(user._id, {
      isSubscribedToDelivery: true,
      subscriptionValidUntil: activeUntil,
    });

    return { success: true, validUntil: activeUntil };
  },
});

// E. DEMANDER UN RETRAIT (Envoyer l'argent de l'app vers son Mobile Money réel)
export const requestWithdrawal = mutation({
  args: { amount: v.number(), phoneNumber: v.string() },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new Error("Non authentifié");

    const user = await ctx.db
      .query("users")
      .withIndex("by_clerkId", (q) => q.eq("clerkId", identity.subject))
      .unique();
    if (!user) throw new Error("Utilisateur introuvable");

    if (user.withdrawableBalance < args.amount) {
      throw new Error("Solde insuffisant pour ce retrait");
    }

    // Déduire immédiatement de sa balance sur l'app
    await ctx.db.patch(user._id, {
      withdrawableBalance: user.withdrawableBalance - args.amount,
    });

    // Ici en production, tu enregistreras cette demande dans une table "withdrawals"
    // pour que ton équipe lui envoie manuellement le Mobile Money (Mvola/Orange/Airtel) 
    return { success: true, remainingBalance: user.withdrawableBalance - args.amount };
  },
});
