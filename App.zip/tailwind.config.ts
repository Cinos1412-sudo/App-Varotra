/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      boxShadow: {
        // Ombre portée du verre + reflet interne brillant en haut (spéculaire)
        'glass': '0 8px 32px 0 rgba(0, 0, 0, 0.3), inset 0 1px 2px 0 rgba(255, 255, 255, 0.25)',
        'glass-hover': '0 12px 40px 0 rgba(0, 0, 0, 0.45), inset 0 1px 3px 0 rgba(255, 255, 255, 0.4)',
        'glow-boost': '0 0 20px 2px rgba(234, 179, 8, 0.5)', // Lueur dorée pour les articles boostés
      },
      animation: {
        'fluid-blob': 'blob-spin 12s infinite alternate linear',
      },
      keyframes: {
        'blob-spin': {
          '0%': { transform: 'translate(0px, 0px) scale(1) rotate(0deg)', borderRadius: '40% 60% 70% 30% / 40% 50% 60% 50%' },
          '50%': { transform: 'translate(40px, -60px) scale(1.2) rotate(180deg)', borderRadius: '70% 30% 50% 50% / 30% 60% 40% 70%' },
          '100%': { transform: 'translate(-20px, 20px) scale(0.9) rotate(360deg)', borderRadius: '40% 60% 70% 30% / 40% 50% 60% 50%' },
        }
      }
    },
  },
  plugins: [],
};
