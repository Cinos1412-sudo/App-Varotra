import { useState } from "react";

export function useImageUpload() {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);

  // Simulation d'une capture caméra ou sélection galerie
  const selectImageSimulation = () => {
    setIsUploading(true);
    
    // Banques d'images d'illustration pour nos tests
    const mockImages = [
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=600&q=80", // Sneakers
      "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80", // Casque audio
      "https://images.unsplash.com/photo-1616077168079-7e09a677fb2c?auto=format&fit=crop&w=600&q=80"  // Reçu SMS
    ];

    setTimeout(() => {
      const randomImg = mockImages[Math.floor(Math.random() * mockImages.length)];
      setImagePreview(randomImg);
      setIsUploading(false);
    }, 800); // Petit effet de chargement réaliste de 800ms
  };

  const clearImage = () => {
    setImagePreview(null);
  };

  return {
    imagePreview,
    isUploading,
    selectImageSimulation,
    clearImage,
  };
}